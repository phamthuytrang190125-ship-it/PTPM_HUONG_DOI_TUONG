package vn.edu.hcmunre.library.app;

public class Main {
    public static void main(String[] args) {
        System.out.println("Library OOAD starter project is ready.");
    }
}
