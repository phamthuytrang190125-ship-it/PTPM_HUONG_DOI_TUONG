## Checkpoint Step 16
- Thoi gian: $(date "+%Y-%m-%d %H:%M:%S")
- Thao tac: Tao file environment.txt chua phien ban cong cu.
- Ket qua: Expected result dat duoc (File chua day du 4 nhom thong tin).
## Checkpoint Step 17
- Thoi gian: $(date "+%Y-%m-%d %H:%M:%S")
- Thao tac: Khoi tao Git repo va thuc hien first commit.
- Ket qua: Expected result dat duoc (git log hien thi commit "chore: initialize OOAD lab project").
