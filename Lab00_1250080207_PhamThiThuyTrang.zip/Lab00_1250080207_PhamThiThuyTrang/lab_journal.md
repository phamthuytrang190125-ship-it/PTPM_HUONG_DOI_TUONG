## Checkpoint Step 05
- Thoi gian: $(date "+%Y-%m-%d %H:%M:%S")
- Thao tac: Cai dat Apache Maven 3.9.16 vao thu muc tuong duong qua Homebrew tren macOS.
- Ket qua: Khong giai nen long cap thu muc ngoai y muon. Cac thu muc bin, conf, lib nam truc tiep duoi libexec.
